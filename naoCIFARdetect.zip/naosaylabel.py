from naoqi import ALProxy #NAO ROBOT CONDA ENVIRONMENT

tts = ALProxy("ALTextToSpeech", '127.0.0.1', 9559)
with open("label.txt", "r") as file:
    text = " ".join(line.rstrip() for line in file)
tts.say("I see a "+ text)