from naoqi import ALProxy #NAO ROBOT CONDA ENVIRONMENT

# Create a proxy to ALPhotoCapture
try:
  photoCaptureProxy = ALProxy("ALPhotoCapture", '127.0.0.1', 9559)
except Exception as e:
  print("Error when creating ALPhotoCapture proxy:")
  print(str(e))
  exit(1)

photoCaptureProxy.setResolution(2)
photoCaptureProxy.setPictureFormat("png")
photoCaptureProxy.takePictures(1, "/data/home/nao/images", "naoImage")
