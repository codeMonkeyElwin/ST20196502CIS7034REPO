from PIL import Image #CI CONDA ENVIRONMENT
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.models import load_model
import numpy as np
import paramiko
import os
import cv2
#from Social_Service.robot_IP import robot_IP

labels = ['airplane', 'automobile', 'bird', 'cat', 'deer', 
          'dog', 'frog', 'horse', 'ship', 'truck']

image_path = '/data/home/nao/images/naoImage.png'
local_path = os.getcwd()

robot_IP='172.18.16.53'
robot_username='nao'
robot_password='nao'

try:
    # Connect to the robot via SSH
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(robot_IP, username=robot_username, password=robot_password)

    command = 'cd /data/home/nao/programs && PYTHONPATH=/opt/aldebaran/lib/python2.7/site-packages python naophotocapture.py'
    (stdin, stdout, stderr) = ssh_client.exec_command(command)

    ssh_client.close()

except Exception as e:
    exit(1)

try:
    # Connect to the robot via SSH
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(robot_IP, username=robot_username, password=robot_password)

    # Create SFTP session
    sftp = ssh_client.open_sftp()

    # Download the file from the robot to the local machine
    local_image_path = os.path.join(local_path, 'NAO-ROBOT//DL//naoImage.png')
    sftp.get(image_path, local_image_path)

    # Close the SFTP session and SSH client
    sftp.close()
    ssh_client.close()

except Exception as e:
    exit(1)
    
def load_image(filename):
	img = load_img(filename, target_size=(32, 32))
	img = img_to_array(img)
	img = img.reshape(1, 32, 32, 3)
	img = img.astype('float32')
	img = img / 255.0
	return img
 
def run_example():
	img = Image.open("C:/Users/elwoo/Documents/coding/python/NAO-ROBOT/DL/naoImage.png")
	imgSmall = img.resize((128,128), resample=Image.Resampling.BILINEAR)
	result = imgSmall.resize(img.size, Image.Resampling.NEAREST)
	result.save('C:/Users/elwoo/Documents/coding/python/NAO-ROBOT/DL/naoImage.png')

	img = load_image('C:/Users/elwoo/Documents/coding/python/NAO-ROBOT/DL/naoImage.png')
	model = load_model('C:/Users/elwoo/Documents/coding/python/VisionwithDL/cnn_50_epochs.h5')
	token_list = model.predict(img)
	result=np.argmax(token_list,axis=1)
	class_num = result[0]
	print(class_num)
	f = open("NAO-ROBOT\DL\label.txt", "w")
	f.write(labels[class_num])
	f.close()
run_example()

naopath = '//data//home//nao//programs//label.txt'
label_path = 'C:/Users/elwoo/Documents/coding/python/NAO-ROBOT/DL/label.txt'
try:
    # Connect to the robot via SSH
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(robot_IP, username=robot_username, password=robot_password)

    # Create SFTP session
    sftp = ssh_client.open_sftp()

    sftp.put(label_path, naopath)

    command = 'cd /data/home/nao/programs && PYTHONPATH=/opt/aldebaran/lib/python2.7/site-packages python naosaylabel.py'
    (stdin, stdout, stderr) = ssh_client.exec_command(command)

    # Close the SFTP session and SSH client
    sftp.close()
    ssh_client.close()

except Exception as e:
    exit(1)


with open("C:/Users/elwoo/Documents/coding/python/NAO-ROBOT/DL/label.txt", "r") as file:
    text = " ".join(line.rstrip() for line in file)
print("I see a "+ text)

image = cv2.imread('C:/Users/elwoo/Documents/coding/python/NAO-ROBOT/DL/naoImage.png',1)
cv2.imshow('image', image)
cv2.waitKey(0)
cv2.destroyAllWindows()